/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Arrow2 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("arrow1-a", "./Arrow2/costumes/arrow1-a.svg", {
        x: 27.589812145602764,
        y: 22.94742668733278,
      }),
      new Costume("arrow1-b", "./Arrow2/costumes/arrow1-b.svg", {
        x: 28,
        y: 23,
      }),
      new Costume("arrow1-c", "./Arrow2/costumes/arrow1-c.svg", {
        x: 23,
        y: 28,
      }),
      new Costume("arrow1-d", "./Arrow2/costumes/arrow1-d.svg", {
        x: 23,
        y: 28,
      }),
    ];

    this.sounds = [new Sound("pop", "./Arrow2/sounds/pop.wav")];

    this.triggers = [new Trigger(Trigger.CLICKED, this.whenthisspriteclicked)];
  }

  *whenthisspriteclicked() {
    this.stage.costume = "previous backdrop";
  }
}
